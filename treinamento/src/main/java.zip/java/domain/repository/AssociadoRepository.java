package domain.repository;

import org.springframework.data.repository.CrudRepository;

import domain.model.Associado;

public interface AssociadoRepository extends CrudRepository<Associado, Long>{

}
